function updateStatus(statusIndex) {
    const statusItems = document.getElementsByClassName('status-item');
    
    // Actualizar el estado activo
    for (let i = 0; i < statusItems.length; i++) {
      statusItems[i].classList.remove('active');
    }
    statusItems[statusIndex].classList.add('active');
  }
  
  // Ejemplo de cambio de estados
  // Selecciona el estado actual
  const estadoActual = 2; // Por ejemplo, el estado de "Reparto"
  
  // Llamada a la función para actualizar el estado
  updateStatus(estadoActual);