## VIEW  - URLS - HTML

from django.urls import path , include
from .views import *
from rest_framework import routers




# RUTAS DEL API
routers = routers.DefaultRouter()
routers.register('Productos' , ProductoViewSet )
routers.register('Tipo Productos' , TipoProductoViewSet )
routers.register('Contacto' ,  ContactoViewSet )
routers.register('Seguimiento' , SeguimientoViewSet )

urlpatterns = [
    # API
    path('api/', include(routers.urls)),
    path('read_product_api/', read_product_api , name="read_product_api"),

    path('blank/', blank , name="blank"),
    path('checkout/', checkout , name="checkout"),
    path('', index , name="index"),
    path('product/', product , name="product"),
    path('store/', store , name="store"),
    path('login/', login , name="login"),
    path('suscribe/', suscribe , name="suscribe"),
    path('alimento/', alimento , name="alimento"),
    path('juguetes/', juguetes , name="juguetes"),
    path('ropa/', ropa , name="ropa"),
    path('cart/', cart , name="cart"),
    path('likes/', likes , name="likes"),
    path('contacto/', contacto , name="contacto"),
    path('seguimiento/', seguimiento , name="seguimiento"),
    path('registro/', registro , name="registro"),

    #CRUD
    path('add_product/', add_product , name="add_product"),
    path('update_product/<id>/', update_product , name="update_product"),
    path('delete_product/<id>/', delete_product , name="delete_product"),
    path('read_product/', read_product , name="read_product"),

    path('stock/', mostrar_stock, name='mostrar_stock'),
    path('actualizar_stock/<int:producto_id>/', actualizar_stock, name='actualizar_stock'),

    path('historial-compras/',historial_compras, name='historial_compras'),
    path('update_seguimiento/<int:id>', update_seguimiento, name="update_seguimiento"),

]



