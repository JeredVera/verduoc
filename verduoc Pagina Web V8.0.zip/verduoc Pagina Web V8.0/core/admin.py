from django.contrib import admin
from .models import *
# Register your models here.

class ProductosAdmin(admin.ModelAdmin):
    list_display = ["nombre", "precio" , "stock" , "tipo"]
    list_editable = ["precio" , "stock" , "tipo"]
    search_fields = ["nombre"]
    list_filter = ['tipo']
    list_per_page = 10
    
admin.site.register(TipoProducto)
admin.site.register(Producto , ProductosAdmin)
admin.site.register(Contacto)
admin.site.register(Suscripcion)
admin.site.register(Seguimiento)