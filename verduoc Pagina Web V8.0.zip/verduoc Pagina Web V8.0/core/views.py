from django.shortcuts import render, redirect , get_object_or_404 
from django.contrib.auth.decorators import login_required , user_passes_test #cada pagina que hay que verse loguiado se ingresa @login_required encima
from .models import *
from .forms import * 
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import Http404
from rest_framework import viewsets
from .serializers import *
from carro.carro import *
from .urls import *
import requests


# FUNCION GENERICA QUE VALIDA LOS GRUPOS
# USO : @grupo_requerido ('vendedor')
def grupo_requerido(nombre_grupo):
    def decorator(view_func):
        @user_passes_test(lambda user :user.groups.filter(name=nombre_grupo).exists())
        def wrapper(request, *args , **kwargs):
            return view_func(request, *args , **kwargs)
        return wrapper
    return decorator

# IMPORT from django.contrib.model import group
# grupo = Group.objects.get(name='Cliente')
# user.groups.add(grupo) 

# SE ENCARGA DE MOSTRAR EN LA VISTA LOS DATOS
class ProductoViewSet(viewsets.ModelViewSet) :
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

class TipoProductoViewSet(viewsets.ModelViewSet) :
    queryset = TipoProducto.objects.all()
    serializer_class = TipoProductoSerializer

class ContactoViewSet(viewsets.ModelViewSet) :
    queryset = Contacto.objects.all()
    serializer_class = ContactoSerializer

class SeguimientoViewSet(viewsets.ModelViewSet) :
    queryset = Seguimiento.objects.all()
    serializer_class = SeguimientoSerializer

# Create your views here.
## VIEW  - URLS - HTML

@grupo_requerido ('administradores')
def blank(request):
    return render (request,'core/blank.html') 

@grupo_requerido ('administradores')
def checkout(request):
    return render (request,'core/checkout.html') 

@grupo_requerido ('cliente')
def index(request):
    ProductoAll = Producto.objects.all()

    respuesta2 = requests.get('https://mindicador.cl/api/')
    monedas = respuesta2.json()

    data = {
        'Listado' : ProductoAll, 
        'monedas' : monedas
    }
    return render (request,'core/index.html' , data) 

@grupo_requerido ('administradores')
def product(request):
    return render (request,'core/product.html') 

@grupo_requerido ('administrador')
def store(request):
    return render (request,'core/store.html') 

def login(request):
    return render (request,'core/login.html') 

@grupo_requerido ('cliente')
def alimento(request):
    ProductoAll = Producto.objects.all()
    data = {
        'Listado' : ProductoAll  
    }
    return render (request,'core/alimento.html' , data) 

@grupo_requerido ('cliente')
def juguetes(request):
    ProductoAll = Producto.objects.all()
    data = {
        'Listado' : ProductoAll  
    }
    return render (request,'core/juguetes.html' , data) 

@grupo_requerido ('cliente')
def ropa(request):
    ProductoAll = Producto.objects.all()
    data = {
        'Listado' : ProductoAll  
    }
    return render (request,'core/ropa.html' , data) 

@grupo_requerido ('cliente')
def cart(request):

    respuesta = requests.get('https://mindicador.cl/api/dolar').json()
    valor_usd = respuesta['serie'][0]['valor']
    valor_carrito = 20000 #ciclo for para sumar todos los productos del carrito
    #convertimos de clp a usd
    valor_total = valor_carrito/valor_usd
    data = {
        'dolar' : round(valor_total, 2)
    }

    return render(request,'core/cart.html', data)

@grupo_requerido ('cliente')
def likes(request):
    return render (request,'core/likes.html') 

def contacto(request) :
    data = {
        'form' : ContactoForm()
    }
    
    if request.method == 'POST':
        formulario = ContactoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data ["mensaje"] = "Mensaje Enviado"
        else :
            data ["form"] = formulario

    return render (request,'core/contacto.html' , data)

@grupo_requerido ('cliente')
def suscribe(request):
    data = {
        'form' : SuscripcionForm()
    }

    if request.method == 'POST':
        formulario = SuscripcionForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            data ["mensaje"] = "Suscrito Correctamente"
        else :
            data ["form"] = formulario

    return render (request,'core/suscribe.html' , data )

@grupo_requerido ('cliente')
def seguimiento(request):
    SeguimientoAll = Seguimiento.objects.all()
    data = {
        'Listado' :  SeguimientoAll
    }
    return render (request,'core/seguimiento.html' , data) 


def registro(request):
    if request.method == 'POST':
        form = CrearUsuario(request.POST)
        if form.is_valid():
            usuario = form.save()
            messages.success(request, 'Cuenta Creada correctamente')

            login(request, usuario)

            cliente = User.objects.get(username = usuario.username)
            cliente.groups.add(1)
            cliente.save()

            return redirect('index')

    else:
        form = CrearUsuario()

    return render(request, 'registration/registro.html', {'form': form})



# CRUD
@grupo_requerido ('vendedor')
def add_product(request):
    data = {
        'form' : ProductoForm()
    }
    if request.method == 'POST':
        formulario = ProductoForm(data=request.POST , files=request.FILES)
        if formulario.is_valid():
            formulario.save()
            messages.success(request , "Agregado Correctamente")
            return redirect(to="index")
        else :
            data["form"] = formulario

    return render (request,'core/add_product.html', data) 

@grupo_requerido ('vendedor')
def update_product(request, id):
    producto = Producto.objects.get(id=id)
    data = {
        'form' : ProductoForm(instance=producto)
    }

    if request.method == 'POST':
        formulario = ProductoForm(data=request.POST,instance=producto, files=request.FILES) # RECIBE EL CONTENIDO DEL FORMULARIO
        if formulario.is_valid():
            formulario.save() # INSERT
            messages.success(request , "Editado Correctamente")
            return redirect(to="index")
        else :
            data['form'] = formulario

    return render (request,'core/update_product.html', data)

@grupo_requerido ('vendedor')
def delete_product(request, id):
    producto = Producto.objects.get(id=id)
    producto.delete()

    return redirect(to="index")

@grupo_requerido ('vendedor')
def read_product(request):
    ProductoAll = Producto.objects.all()
    page = request.GET.get('page', 1) 

    try:
        paginator = Paginator(ProductoAll , 5)
        ProductoAll = paginator.page(page)
    except:
        raise Http404

    data = {
        'entity' : ProductoAll,
        'paginator' : paginator
    }

    return render(request,'core/read_product.html' , data)

# API
@grupo_requerido ('administradores')
def read_product_api(request):
    # SOLICITUD DE API
    respuesta = requests.get('http://127.0.0.1:8000/api/productos/')
    respuesta2 = requests.get('https://mindicador.cl/api/')
    respuesta3 = requests.get('https://rickandmortyapi.com/api/character')
    
    # TRANSFORMAMOS EL JSON PARA LEERLO
    productos = respuesta.json()
    monedas = respuesta2.json()
    aux = respuesta3.json()
    personajes = aux['results']

    data = {
        'entity' : productos,
        'monedas' : monedas,
        'personajes' : personajes,
    }

    return render(request,'core/read_product_api.html' , data)


#CRUD CARRITO   
def cart_add(request, id):
    cart = Carro(request)
    producto = Producto.objects.get(id=id)
    cart.add(producto=producto)
    return redirect("cart")


def item_clear(request, id):
    cart = Carro(request)
    producto = Producto.objects.get(id=id)
    cart.remove(producto)
    return redirect("cart")


def item_decrement(request, id):
    cart = Carro(request)
    producto = Producto.objects.get(id=id)
    cart.decrement(producto=producto)
    return redirect("cart")

def item_increment(request, id):
    cart = Carro(request)
    producto = Producto.objects.get(id=id)
    cart.add(producto=producto)
    return redirect("cart")


def cart_clear(request, producto_id):
    carro=Carro(request)
    carro.clear()
    return redirect("cart")


def cart_detail(request):
    return render(request, 'core/cart.html')

def eliminar_producto(request, producto_id):
    carro=Carro(request)
    producto=Producto.objects.get(id=producto_id)
    carro.remove(producto=producto)

    return redirect("cart")


def mostrar_stock(request):
    productos = Producto.objects.all()
    return render(request, 'core/mostrar_stock.html', {'producto': productos})

def actualizar_stock(request, producto_id):
    producto = get_object(Producto, producto_id)
    
    if request.method == 'POST':
        nuevo_stock = int(request.POST['stock'])
        producto.stock = nuevo_stock
        producto.save()
        
        return JsonResponse({'mensaje': 'Stock actualizado correctamente.'})
        
    return render(request, 'actualizar_stock.html', {'producto': producto})


def historial_compras(request):
    compras = Compra.objects.filter(usuario=request.user)
    return render(request, 'core/historial_compras.html', {'compras': compras})


def update_seguimiento(request , id ):
    seguimiento = Seguimiento.objects.get(id=id)
    data = {
        'form' : SeguimientoForm(instance=seguimiento)
    }

    if request.method == 'POST':
        formulario = SeguimientoForm(data=request.POST,instance=seguimiento, files=request.FILES) # RECIBE EL CONTENIDO DEL FORMULARIO
        if formulario.is_valid():
            formulario.save() # INSERT
            messages.success(request , "Editado Correctamente")
            return redirect(to="index")
        else :
            data['form'] = formulario

    return render (request,'core/update_seguimiento.html', data)

