document.addEventListener('DOMContentLoaded', function() {
    // Tu código JavaScript aquí
  
    // Obtén el elemento de la barra de progreso
    const progressBar = document.getElementById('progress-bar');
  
    // Obtén el valor de s.descripcion
    const descripcion = progressBar.getAttribute('data-descripcion');
  
    // Imprime el valor de descripcion en la consola
    console.log(descripcion);
  
    // Define un objeto que mapea la descripción a un valor numérico
    const descripcionValues = {
      'validacion': 25,
      'preparacion': 50,
      'reparto': 75,
      'entregado': 100
    };
  
    // Función para actualizar el valor de la barra de progreso
    function updateProgressBar(value) {
      progressBar.value = value;
    }
  
    // Verifica si la descripción existe en el objeto de valores y actualiza la barra de progreso
    if (descripcionValues.hasOwnProperty(descripcion)) {
      const progressValue = descripcionValues[descripcion];
      updateProgressBar(progressValue);
    }
  });
  
  