from django import forms
from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class TipoProducto(models.Model):
    descripcion = models.CharField(max_length=100)

    def __str__(self):
        return self.descripcion

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio = models.IntegerField()
    stock = models.IntegerField()
    descripcion = models.CharField(max_length=200)
    tipo = models.ForeignKey(TipoProducto, on_delete=models.CASCADE)
    vencimiento = models.DateField()
    imagen = models.ImageField(null=True,blank=True)
    favorito = models.BooleanField()

    def __str__(self):
        return self.nombre


opciones_consultas = [
    [0, "consulta"],
    [1, "reclamo"],
    [2, "sugerencia"],
    [3, "felicitaciones"]
    
]


class Contacto(models.Model):
    nombre = models.CharField(max_length=100)
    correo = models.EmailField()
    tipo_consulta = models.IntegerField(choices=opciones_consultas)
    mensaje = models.TextField()
    avisos = models.BooleanField()

    def __str__(self):
        return self.nombre


class Suscripcion(models.Model):
    nombre = models.CharField(max_length=100)
    contrasena = models.CharField(max_length=15)
    correo = models.EmailField()
    numero_tarjeta = models.IntegerField(max_length=16)
    vencimiento = models.DateField()
    cvv = models.IntegerField(max_length=3)

    def __str__(self):
        return self.nombre


class Seguimiento(models.Model):
    descripcion = models.CharField(max_length=100)

    def __str__(self):
        return self.descripcion
    

class Compra(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    fecha = models.DateTimeField(auto_now_add=True)

    # Otros campos relevantes para tu aplicación

    def __str__(self):
        return f'Compra {self.id} - {self.usuario.username}'
    
